﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _21120560
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void textEmail_MouseDown(object sender, MouseButtonEventArgs e)
        {
            txtEmail.Focus();
        }

        private void txtEmail_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtEmail.Text) && txtEmail.Text.Length > 0)
                textEmail.Visibility = Visibility.Collapsed;
            else
                textEmail.Visibility = Visibility.Visible;
        }


        private void textPassword_MouseDown(object sender, MouseButtonEventArgs e)
        {
            txtPasswordBox.Focus();
        }

        private void txtPasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtPasswordBox.Password) && txtPasswordBox.Password.Length > 0)
                textPassword.Visibility = Visibility.Collapsed;
            else
                textPassword.Visibility = Visibility.Visible;
        }
    

        private void Image_MouseUp(object sender, MouseButtonEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void logInButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtEmail.Text) && !string.IsNullOrEmpty(txtPasswordBox.Password))
            {
                MessageBox.Show("Successfully Signed In");

            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;

            string bufferImgClose = "assets/close.png";
            string t_imgClose = $"{baseDirectory}{bufferImgClose}";
            var bitmapImgClose = new BitmapImage(new Uri(t_imgClose, UriKind.Absolute));
            imgClose.Source = bitmapImgClose;

            string bufferImgEmail = "assets/email.png";
            string t_imgEmail = $"{baseDirectory}{bufferImgEmail}";
            var bitmapImgEmail = new BitmapImage(new Uri(t_imgEmail, UriKind.Absolute));
            imgEmail.Source = bitmapImgEmail;

            string bufferImgPassword = "assets/password.png";
            string t_imgPassword = $"{baseDirectory}{bufferImgPassword}";
            var bitmapImgPassword = new BitmapImage(new Uri(t_imgPassword, UriKind.Absolute));
            imgPassword.Source = bitmapImgPassword;

        }
    }
}
